// Seleção de elementos
const btnInc = document.getElementById("botar");
const btnDec = document.getElementById("tirar");
const contadorSpan = document.getElementById("contador");

const campoTexto = document.getElementById("campo-texto");
const contadorCaracteres = document.getElementById("contador-caracteres");
const areaTextos = document.getElementById("area-textos");

const tipoLista = document.getElementById("tipo-lista");
const btnLista = document.getElementById("botar_lista");
const areaItens = document.getElementById("area-itens");

const btnReset = document.getElementById("apagar");

let contador = 0;

// Incrementar
btnInc.addEventListener("click", () => {
  contador++;
  contadorSpan.textContent = contador;
});

// Decrementar
btnDec.addEventListener("click", () => {
  if (contador > 0) {
    contador--;
    contadorSpan.textContent = contador;
  } else {
    alert("O contador já está em zero!");
  }
});

// Contador de caracteres (sem espaços)
campoTexto.addEventListener("input", () => {
  const textoSemEspacos = campoTexto.value.replace(/\s/g, "");
  contadorCaracteres.textContent = textoSemEspacos.length;
});

// Adicionar texto ao pressionar Enter
campoTexto.addEventListener("keypress", (e) => {
  if (e.key === "Enter" && campoTexto.value.trim() !== "") {
    const p = document.createElement("p");
    p.textContent = campoTexto.value;
    areaTextos.appendChild(p);

    campoTexto.value = "";
    contadorCaracteres.textContent = 0;
  }
});

// Adicionar lista
btnLista.addEventListener("click", () => {
  const tipo = tipoLista.value;
  const lista = document.createElement(tipo);

  for (let i = 1; i <= 3; i++) {
    const li = document.createElement("li");
    li.textContent = "Item " + i;
    lista.appendChild(li);
  }

  areaItens.appendChild(lista);
});

// Resetar tudo
btnReset.addEventListener("click", () => {
  contador = 0;
  contadorSpan.textContent = contador;

  areaTextos.innerHTML = "";
  areaItens.innerHTML = "";

  campoTexto.value = "";
  contadorCaracteres.textContent = 0;
});