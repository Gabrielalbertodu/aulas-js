
//varievel
//var
//let
//const
var anima="gato"; 
console.log(anima);
var anima="pauno cusito";
console.log(anima);

let nomedegay="augusto carrara";
console.log(nomedegay);

const valor0=10;
//não pode -> valor0=20;
var valor1;
console.log(typeof valor0);

var nome = window.prompt("digita o nome: ");
console.log("nome digitado: "+ nome + "crioulo");

var n1=parseFloat(window.prompt("n1: "));
console.log(typeof n1);
var n2=parseFloat(window.prompt("n2: "));
console.log(typeof n2);
var resultado=n1+n2;
console.log("resultado: " + resultado);

